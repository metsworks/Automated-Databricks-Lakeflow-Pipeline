CREATE OR REFRESH STREAMING LIVE TABLE lakeflow_dlt_nypd.silver.silver
COMMENT "Silver Table"
TBLPROPERTIES ("quality" = "silver")
AS
SELECT
  CAST(ARREST_KEY AS BIGINT) AS arrest_key,
  TO_DATE(ARREST_DATE, 'MM/dd/yyyy') AS arrest_date,
  CAST(PD_CD AS INT) AS pd_code,
  TRIM(REGEXP_REPLACE(UPPER(COALESCE(PD_DESC, 'MISSING_PD_DESC')), '\\s+', ' ')) AS pd_desc,
  CAST(KY_CD AS DOUBLE) AS ky_code,
  OFNS_DESC AS ofns_desc,
  LAW_CODE AS law_code,
  CASE 
    WHEN LAW_CAT_CD = 'F' THEN 'Felony'
    WHEN LAW_CAT_CD = 'M' THEN 'Misdemeanor'
    WHEN LAW_CAT_CD = 'V' THEN 'Violation'
    WHEN LAW_CAT_CD = 'I' THEN 'Infraction'
    ELSE 'Unknown'
  END AS law_category_code,
  
  CASE
    WHEN ARREST_BORO = 'B' THEN 'Bronx'
    WHEN ARREST_BORO = 'K' THEN 'Brooklyn'
    WHEN ARREST_BORO = 'M' THEN 'Manhattan'
    WHEN ARREST_BORO = 'Q' THEN 'Queens'
    WHEN ARREST_BORO = 'S' THEN 'Staten Island'
    ELSE 'Unknow' 
  END AS arrest_boro,
  CAST(ARREST_PRECINCT AS INT) AS arrest_precinct,
  
  CASE 
    WHEN CAST(JURISDICTION_CODE AS INT) = 0 THEN 'Patrol'
    WHEN CAST(JURISDICTION_CODE AS INT) = 1 THEN 'Transit'
    WHEN CAST(JURISDICTION_CODE AS INT) = 2 THEN 'Housing'
    ELSE 'Non-NYPD Jurisdiction' 
  END AS jurisdiction_code, 
  
  AGE_GROUP AS age_group,
  PERP_SEX AS perp_sex,
  PERP_RACE AS perp_race,
  CAST(X_COORD_CD AS INT) AS x_coord_cd,
  CAST(Y_COORD_CD AS INT) AS y_coord_cd,
  CAST(Latitude AS DOUBLE) AS latitude,
  CAST(Longitude AS DOUBLE) AS longitude
    
  
FROM STREAM(lakeflow_dlt_nypd.bronze.bronze)
