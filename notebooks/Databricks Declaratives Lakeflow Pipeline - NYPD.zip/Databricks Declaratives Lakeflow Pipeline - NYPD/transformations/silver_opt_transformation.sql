CREATE OR REFRESH MATERIALIZED VIEW lakeflow_dlt_nypd.silver.silver_opt (
  -- Data quality expectations
  CONSTRAINT unique_arrest_key EXPECT (arrest_key IS NOT NULL) ON VIOLATION DROP ROW,
  CONSTRAINT valid_arrest_date EXPECT (arrest_date IS NOT NULL) ON VIOLATION DROP ROW,
  CONSTRAINT valid_key_code EXPECT (ky_code IS NOT NULL) ON VIOLATION DROP ROW,
  CONSTRAINT valid_arrest_boro EXPECT (arrest_boro IS NOT NULL) ON VIOLATION DROP ROW,
  CONSTRAINT valid_arrest_precint EXPECT (arrest_precinct IS NOT NULL) ON VIOLATION DROP ROW,
  CONSTRAINT valid_perp_sex EXPECT (perp_sex IN ('M', 'F')) ON VIOLATION DROP ROW,
  CONSTRAINT valid_perp_race EXPECT (perp_race IN (
    'BLACK', 
    'UNKNOWN',
    'ASIAN / PACIFIC ISLANDER', 
    'WHITE HISPANIC', 
    'BLACK HISPANIC', 
    'WHITE', 
    'AMERICAN INDIAN/ALASKAN NATIVE'
  )) ON VIOLATION DROP ROW,
  CONSTRAINT valid_age_group EXPECT (age_group IN ('25-44', '18-24', '45-64', '65+', '<18')) ON VIOLATION DROP ROW
)
COMMENT "Silver Optimized Layer - Materialized View for clean and stable analytical data"
TBLPROPERTIES ("quality" = "silver_optimized")
AS

WITH initial_filtering AS (
    SELECT
        * ,
        CASE
            WHEN law_category_code IS NULL AND law_code = 'FOA9000049' THEN 'Unknown'
            ELSE law_category_code
        END AS law_category_code_fixed
    FROM LIVE.silver
    WHERE NOT (ky_code IS NULL AND ofns_desc = '(NULL)' AND pd_desc = '(NULL)')
),

spell_check AS (
    SELECT
        REPLACE(
            REPLACE(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            REPLACE(pd_desc, 
                                ' UNCLASSIFIE', ' UNCLASSIFIED'),
                            ' ADMINISTATION', ' ADMINISTRATION'),
                        ' OFFENSIV', ' OFFENSIVE'),
                    ' POSSESSE', ' POSSESSION'),
                ' ASBUSE', ' ABUSE'),
            ' UNECESSARY', ' UNNECESSARY'
        ) AS pd_desc_corrected,
        * EXCEPT (pd_desc)
    FROM initial_filtering
),

pd_desc_corrected AS (
    SELECT
        *,
        CASE
            WHEN pd_desc_corrected LIKE 'ASSAULT %' OR pd_desc_corrected LIKE 'STRANGULATION%' OR pd_desc_corrected LIKE 'MENACING%' OR pd_desc_corrected LIKE 'OBSTR BREATH/CIRCUL' THEN 'ASSAULT/VIOLENCE'
            WHEN pd_desc_corrected LIKE 'MURDER%' OR pd_desc_corrected LIKE 'HOMICIDE%' OR pd_desc_corrected LIKE 'MANSLAUGHTER%' THEN 'HOMICIDE/MURDER'
            WHEN pd_desc_corrected LIKE 'ROBBERY%' THEN 'ROBBERY/HOLDUP'
            WHEN pd_desc_corrected LIKE 'RAPE %' OR pd_desc_corrected LIKE 'SEXUAL ABUSE%' OR pd_desc_corrected LIKE 'SEX TRAFFICKING%' OR pd_desc_corrected LIKE 'FORCIBLE TOUCHING' OR pd_desc_corrected LIKE 'SODOMY%' THEN 'SEX CRIME/ABUSE'
            WHEN pd_desc_corrected LIKE 'LARCENY,GRAND %' OR pd_desc_corrected LIKE 'LARCENY,PETIT%' OR pd_desc_corrected LIKE 'THEFT OF SERVICES%' OR pd_desc_corrected LIKE 'JOSTLING' THEN 'LARCENY/THEFT'
            WHEN pd_desc_corrected LIKE 'CONTROLLED SUBSTANCE%' OR pd_desc_corrected LIKE 'CANNABIS%' OR pd_desc_corrected LIKE 'DRUG PARAPHERNALIA%' THEN 'DRUGS/NARCOTICS'
            WHEN pd_desc_corrected LIKE 'WEAPONS%' OR pd_desc_corrected LIKE 'FIREARMS%' THEN 'WEAPONS/FIREARMS'
            WHEN pd_desc_corrected LIKE 'IMPAIRED DRIVING%' OR pd_desc_corrected LIKE 'INTOXICATED DRIVING%' THEN 'DWI/DUI'
            WHEN pd_desc_corrected LIKE 'CRIMINAL MISCHIEF%' OR pd_desc_corrected LIKE 'MISCHIEF%' OR pd_desc_corrected LIKE 'ARSON%' THEN 'DAMAGE/MISCHIEF'
            WHEN pd_desc_corrected LIKE 'FORGERY%' OR pd_desc_corrected LIKE 'FRAUD%' OR pd_desc_corrected LIKE 'IMPERSONATION%' THEN 'FRAUD/FORGERY'
            WHEN pd_desc_corrected LIKE 'PROSTITUTION%' THEN 'PROSTITUTION'
            WHEN pd_desc_corrected LIKE 'BURGLARY%' THEN 'BURGLARY'
            WHEN pd_desc_corrected LIKE 'CHILD, ENDANGERING WELFARE%' THEN 'CHILD ENDANGERMENT'
            WHEN pd_desc_corrected LIKE 'RESISTING ARREST' THEN 'RESISTING ARREST'
            WHEN pd_desc_corrected LIKE 'STOLEN PROPERTY%' THEN 'STOLEN PROPERTY, POSSESSION'
            WHEN pd_desc_corrected LIKE 'AGGRAVATED HARASSMENT%' OR pd_desc_corrected LIKE 'HARASSMENT%' THEN 'HARASSMENT'
            WHEN pd_desc_corrected LIKE 'BAIL JUMPING%' THEN 'BAIL JUMPING'
            WHEN pd_desc_corrected LIKE 'GAMBLING%' THEN 'GAMBLING'
            WHEN pd_desc_corrected LIKE 'TRESPASS %' THEN 'TRESPASS'
            WHEN pd_desc_corrected LIKE 'TORTURE/INJURE ANIMAL CRUELTY%' THEN 'ANIMAL CRUELTY'
            WHEN pd_desc_corrected LIKE 'PUBLIC ADMINISTRATION%' THEN 'PUBLIC ADMIN OFFENSE'
            ELSE pd_desc_corrected
        END AS offense_simplified
    FROM spell_check
    WHERE NOT (
        (x_coord_cd = 0) OR (y_coord_cd = 0) OR (latitude = 0.000000) OR (longitude = 0.000000)
    )
),

deduplicated AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY arrest_key ORDER BY arrest_date DESC) AS rn
    FROM pd_desc_corrected
)

SELECT
    arrest_key,
    arrest_date,
    pd_code,
    pd_desc_corrected AS pd_desc,
    offense_simplified,
    ky_code,
    ofns_desc,
    law_code,
    law_category_code_fixed AS law_category_code,
    arrest_boro,
    arrest_precinct,
    jurisdiction_code,
    age_group,
    perp_sex,
    perp_race,
    x_coord_cd,
    y_coord_cd,
    latitude,
    longitude
FROM deduplicated
WHERE rn = 1;
