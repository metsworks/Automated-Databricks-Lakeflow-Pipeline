-- PRECINT TABLE (Dimension)
CREATE OR REFRESH MATERIALIZED VIEW gold.precinct
COMMENT "Dimension table - Precinct (unique precinct_id)"
TBLPROPERTIES ("quality" = "gold")
AS
WITH dedup AS (
    SELECT
        arrest_precinct AS precinct_id,
        FIRST(arrest_boro) AS precinct_boro  
    FROM LIVE.silver.silver_opt
    WHERE arrest_precinct IS NOT NULL AND arrest_boro IS NOT NULL
    GROUP BY arrest_precinct
)
SELECT *
FROM dedup;


-- OFFENSE TABLE (Dimension)
CREATE OR REFRESH MATERIALIZED VIEW gold.offense
COMMENT "Dimension table - Offense (unique law_code)"
TBLPROPERTIES ("quality" = "gold")
AS
SELECT
    law_code,
    law_category_code,
    ky_code AS key_code,
    pd_code,
    ofns_desc AS offense_description
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY law_code ORDER BY law_code) AS rn
    FROM LIVE.silver.silver_opt
    WHERE law_code IS NOT NULL
) tmp
WHERE rn = 1;


-- ARREST TABLE (Fact)
CREATE OR REFRESH MATERIALIZED VIEW gold.arrest
COMMENT "Fact table - Arrest"
TBLPROPERTIES ("quality" = "gold")
AS
WITH dedup AS (
    SELECT
        arrest_key,
        FIRST(arrest_date) AS arrest_date,
        FIRST(arrest_precinct) AS arrest_precinct,
        FIRST(jurisdiction_code) AS jurisdiction_code,
        FIRST(law_code) AS law_code
    FROM LIVE.silver.silver_opt
    WHERE arrest_key IS NOT NULL AND arrest_date IS NOT NULL
    GROUP BY arrest_key
)
SELECT *
FROM dedup;


-- PERPETRATOR TABLE (Dimension)
CREATE OR REFRESH MATERIALIZED VIEW gold.perpetrator
COMMENT "Dimension table - Perpetrator"
TBLPROPERTIES ("quality" = "gold", "domain" = "demographics")
AS
SELECT
    arrest_key,
    age_group,
    perp_sex AS perpetrator_sex,
    perp_race AS perpetrator_race
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY arrest_key ORDER BY arrest_key) AS rn
    FROM LIVE.silver.silver_opt
    WHERE arrest_key IS NOT NULL
) tmp
WHERE rn = 1;


-- SPATIAL TABLE (Dimension)
CREATE OR REFRESH MATERIALIZED VIEW gold.spatial
COMMENT "Dimension table - Spatial (coordinates)"
TBLPROPERTIES ("quality" = "gold")
AS
SELECT
    arrest_key,
    x_coord_cd,
    y_coord_cd,
    latitude,
    longitude,
    CASE
        WHEN latitude IS NOT NULL AND longitude IS NOT NULL THEN 'Yes'
        ELSE 'No'
    END AS georeferenced
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY arrest_key ORDER BY arrest_key) AS rn
    FROM LIVE.silver.silver_opt
    WHERE arrest_key IS NOT NULL
) tmp
WHERE rn = 1;
