CREATE OR REFRESH STREAMING LIVE TABLE lakeflow_dlt_nypd.bronze.bronze
COMMENT "Bronze Table - Raw data ingestion from landing zone"
TBLPROPERTIES ("quality" = "bronze")
AS
SELECT
  ARREST_KEY,
  ARREST_DATE,
  PD_CD,
  PD_DESC,
  KY_CD,
  OFNS_DESC,
  LAW_CODE,
  LAW_CAT_CD,
  ARREST_BORO,
  ARREST_PRECINCT,
  JURISDICTION_CODE,
  AGE_GROUP,
  PERP_SEX,
  PERP_RACE,
  X_COORD_CD,
  Y_COORD_CD,
  Latitude,
  Longitude,
  `New Georeferenced Column` AS New_Georeferenced_Column
FROM cloud_files(
  "/Volumes/lakeflow_dlt_nypd/landing/land_nypd_vol/",
  "csv",
  map(
    "header", "true",
    "inferSchema", "true"
  )
);
